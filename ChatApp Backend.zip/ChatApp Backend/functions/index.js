const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();

// Laver en cloud function som hedder sendNotifications
exports.sendNotifications = functions.https.onRequest(async (request, response) => {
  // Kalder admin.messaging som sender notifikationer
  admin.messaging().sendMulticast({
	tokens: JSON.parse(request.body.data.recievers), // JSON decoder token arrayet som er modtaget fra Fire.js filen
	data: {
	  chatRoomId: `${request.body.data.chatRoomId}`, // Sætter en chatrum ID
	  chatName: `${request.body.data.chatName}` // Sætter en chatrum navn
	},
	notification: {
	  title: 'Ny besked i ' + request.body.data.chatName, // Sætter en titel
	  body: 'Klik her for at gå til chat rummet', // Sætter en beskrivelse
	},
  }).then(() => {
	response.json({success: true}); // Sender success tilbage
  }).catch(() => {
	response.json({success: false}); // Sender error tilbage hvis der skete en fejl
  });
  
});